package main
// TODO: add OTel SDK/Exporter if desired; for demo we rely on infra scraping
